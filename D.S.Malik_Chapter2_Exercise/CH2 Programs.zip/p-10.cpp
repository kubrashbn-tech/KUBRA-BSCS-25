#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double n1, n2, n3, n4, n5;
    cout << "Enter 5 decimal numbers: ";
    cin >> n1 >> n2 >> n3 >> n4 >> n5;

    double sum = n1 + n2 + n3 + n4 + n5;
    int rounded = round(sum);

    cout << "Rounded Sum = " << rounded << endl;
    return 0;
}