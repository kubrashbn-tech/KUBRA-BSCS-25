#include <iostream>
using namespace std;

int main() {
    double advertisedGB;
    cout << "Enter advertised hard drive size (GB): ";
    cin >> advertisedGB;

    // Manufacturer uses 1 GB = 1,000,000,000 bytes
    double bytes = advertisedGB * 1000000000;

    // Computer uses 1 GB = 1024^3 bytes
    double actualGB = bytes / (1024.0 * 1024.0 * 1024.0);

    cout << "Advertised size = " << advertisedGB << " GB" << endl;
    cout << "Actual storage = " << actualGB << " GB" << endl;

    return 0;
}