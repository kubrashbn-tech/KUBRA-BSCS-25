#include <iostream>
using namespace std;

int main() {
    double originalPrice, markupPercent, salesTaxRate;

    cout << "Enter original price: ";
    cin >> originalPrice;
    cout << "Enter markup percentage: ";
    cin >> markupPercent;
    cout << "Enter sales tax rate (in %): ";
    cin >> salesTaxRate;

    double markupAmount = (markupPercent / 100.0) * originalPrice;
    double sellingPrice = originalPrice + markupAmount;
    double taxAmount = (salesTaxRate / 100.0) * sellingPrice;
    double finalPrice = sellingPrice + taxAmount;

    cout << "Original Price = $" << originalPrice << endl;
    cout << "Markup % = " << markupPercent << "%" << endl;
    cout << "Selling Price = $" << sellingPrice << endl;
    cout << "Sales Tax = $" << taxAmount << endl;
    cout << "Final Price = $" << finalPrice << endl;

    return 0;
}