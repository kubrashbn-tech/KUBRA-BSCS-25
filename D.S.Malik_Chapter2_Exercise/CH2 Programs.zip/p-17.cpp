#include <iostream>
using namespace std;

int main() {
    double costPerLiter, profitPerCarton;
    double cartonVolume = 3.78; // liters per carton

    cout << "Enter cost of producing one liter of milk: ";
    cin >> costPerLiter;
    cout << "Enter profit on each carton of milk: ";
    cin >> profitPerCarton;

    double costPerCarton = costPerLiter * cartonVolume;

    cout << "Cost per carton = $" << costPerCarton << endl;
    cout << "Profit per carton = $" << profitPerCarton << endl;
    return 0;
}