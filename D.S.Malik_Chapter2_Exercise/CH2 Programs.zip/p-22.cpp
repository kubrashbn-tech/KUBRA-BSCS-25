#include <iostream>
using namespace std;

int main() {
    double pounds;
    const double ton = 2205;

    cout << "Enter amount of rice in one bag (pounds): ";
    cin >> pounds;

    double bags = ton / pounds;

    cout << "Number of bags needed = " << bags << endl;
    return 0;
}