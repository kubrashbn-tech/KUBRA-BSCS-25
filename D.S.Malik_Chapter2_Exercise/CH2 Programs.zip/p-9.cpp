#include <iostream>
using namespace std;

int main() {
    double s1, s2, s3, s4, s5, average;
    cout << "Enter 5 test scores: ";
    cin >> s1 >> s2 >> s3 >> s4 >> s5;

    average = (s1 + s2 + s3 + s4 + s5) / 5.0;

    cout << "Average Score = " << average << endl;
    return 0;
}