#include <iostream>
using namespace std;

int main() {
    double capacity, mpg, miles;
    cout << "Enter fuel tank capacity (gallons): ";
    cin >> capacity;
    cout << "Enter miles per gallon: ";
    cin >> mpg;

    miles = capacity * mpg;

    cout << "The car can travel " << miles << " miles without refueling." << endl;
    return 0;
}