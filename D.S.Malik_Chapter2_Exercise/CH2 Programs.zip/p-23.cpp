#include <iostream>
using namespace std;

int main() {
    int shares;
    double purchasePrice, sellingPrice;
    cout << "Enter number of shares sold: ";
    cin >> shares;
    cout << "Enter purchase price per share: ";
    cin >> purchasePrice;
    cout << "Enter selling price per share: ";
    cin >> sellingPrice;

    double invested = shares * purchasePrice;
    double totalSell = shares * sellingPrice;

    double serviceCharge = 0.015 * (invested + totalSell);
    double gainOrLoss = totalSell - invested - serviceCharge;

    cout << "Total invested = $" << invested << endl;
    cout << "Total service charges = $" << serviceCharge << endl;
    cout << "Amount gained/lost = $" << gainOrLoss << endl;
    cout << "Amount received after selling = $" << totalSell - serviceCharge << endl;
    return 0;
}