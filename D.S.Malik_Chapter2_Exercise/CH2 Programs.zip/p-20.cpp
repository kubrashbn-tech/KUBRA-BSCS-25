#include <iostream>
using namespace std;

int main() {
    double fixed, percent, cost;
    cout << "Enter salesperson's fixed commission: ";
    cin >> fixed;
    cout << "Enter commission percentage: ";
    cin >> percent;
    cout << "Enter cost of car: ";
    cin >> cost;

    double minPrice = cost + 200;
    double maxPrice = cost + 2000;

    double minCommission = fixed + (percent / 100) * (minPrice - cost);
    double maxCommission = fixed + (percent / 100) * (maxPrice - cost);

    cout << "Minimum selling price = $" << minPrice << endl;
    cout << "Maximum selling price = $" << maxPrice << endl;
    cout << "Commission range = $" << minCommission << " - $" << maxCommission << endl;
    return 0;
}