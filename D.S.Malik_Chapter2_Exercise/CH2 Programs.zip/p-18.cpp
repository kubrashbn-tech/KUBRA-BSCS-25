#include <iostream>
using namespace std;

int main() {
    double payRate, hours, gross, tax, net, clothes, supplies, bonds, parents;

    cout << "Enter hourly pay rate: ";
    cin >> payRate;
    cout << "Enter hours worked per week: ";
    cin >> hours;

    gross = payRate * hours * 5;      // 5 weeks
    tax = gross * 0.14;
    net = gross - tax;
    clothes = net * 0.10;
    supplies = net * 0.01;
    bonds = (net - clothes - supplies) * 0.25;
    parents = bonds * 0.50;

    cout << "Gross Income = $" << gross << endl;
    cout << "After Taxes = $" << net << endl;
    cout << "Clothes & Accessories = $" << clothes << endl;
    cout << "School Supplies = $" << supplies << endl;
    cout << "Bonds = $" << bonds << endl;
    cout << "Parents spend = $" << parents << endl;

    return 0;
}