#include <iostream>
using namespace std;

int main() {
    double M1, M2, d;
    const double k = 6.67e-8;

    cout << "Enter mass M1: ";
    cin >> M1;
    cout << "Enter mass M2: ";
    cin >> M2;
    cout << "Enter distance d: ";
    cin >> d;

    double F = k * (M1 * M2) / (d * d);

    cout << "Force between bodies = " << F << endl;
    return 0;
}