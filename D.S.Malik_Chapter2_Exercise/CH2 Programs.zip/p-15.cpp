#include <iostream>
using namespace std;

int main() {
    const double PI = 3.141593;
    double radius, area, circumference;

    cout << "Enter radius of circle: ";
    cin >> radius;

    area = PI * radius * radius;
    circumference = 2 * PI * radius;

    cout << "Area = " << area << endl;
    cout << "Circumference = " << circumference << endl;

    return 0;
}