#include <iostream>
#include <cmath>
using namespace std;

int main() {
    const double LITERS_PER_CARTON = 3.78;
    const double COST_PER_LITER = 0.38;
    const double PROFIT_PER_CARTON = 0.27;

    double totalMilk;
    cout << "Enter total amount of milk produced (liters): ";
    cin >> totalMilk;

    double cartons = totalMilk / LITERS_PER_CARTON;
    int roundedCartons = round(cartons);
    double cost = totalMilk * COST_PER_LITER;
    double profit = roundedCartons * PROFIT_PER_CARTON;

    cout << "Milk cartons needed = " << roundedCartons << endl;
    cout << "Cost of producing milk = $" << cost << endl;
    cout << "Profit from milk = $" << profit << endl;

    return 0;
}